060rpt - Customization package for OpenBiblio
Copyright � 2009 Hans van der Weij

Version
  Version 1 for OpenBiblio 0.6.x
  december 2009

License
  The license for this package is identical to the license for OpenBiblio,
  see COPYRIGHT.html - OpenBiblio release file
  (GNU GENERAL PUBLIC LICENSE Version 2, with minor exception)

  [citation of COPYRIGHT.html]

    OpenBiblio is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OpenBiblio; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  [end of citation]

Summary
  * Reports, report layouts for producing labels and letters.

  Use with OpenBiblio 0.6.x integrated library software.
  Designed for general use.

Language
  English (all reports and layouts, layouts for A4 paper size)

Support
  OpenBiblio Help Forum (Community support)
  http://sourceforge.net/projects/obiblio/forums/forum/164978
  Hire someone for support? - see section Q&A

Contact author
  <jgvdweij at dds.nl>
    or
  http://sourceforge.net/users/infinite-mnkz/

OpenBiblio official Home Page and Project Page
  http://obiblio.sourceforge.net
  http://sourceforge.net/projects/obiblio


1. INSTALLATION
---------------


1.1 Quick install instructions 
------------------------------

* Copy supplied files to corresponding subdirectories in openbiblio directory.


1.2 Additional packages
-----------------------

Optional additional packages (add-ons and translations):
http://obiblio.sourceforge.net/index.php/Main/AddOns


2. DETAIL INFORMATION
---------------------


2.1 Customized biblio fields
-----------------
Optional: New Bibliography and Edit Bibliography pages can be customized.
File /catalog/biblio_fields.php has a configuration area at the bottom that
determines which fields are used on these pages.
There is an extended version of this reports package that comes with customized
biblio fields. Check the author's site for this package, targeted at secondary
school libraries in The Netherlands ("mediatheken").


2.2 Customized member fields
-----------------
The author's site also offers and extended version of this reports package 
targeted at schools in general. This comes with reports and layouts that are 
aware of custom member fields 'School Grade' and 'School Teacher'. These were 
standard in OpenBiblio version 0.5.1 and lower.
This package for schools is identical to the package targeted at "mediatheken",
but without the modified /catalog/biblio_fields.php


2.3 Customized definition files
-------------------------------

\layouts\labels.php
  Modified from original release: barcode dimensions are optimized for reliable 
  scanning results. Tested successfully with low-resolution inkjet printer.
  Credit for multifunctional label: OpenBiblio 0.4.0 / dstevens77 (Dave Stevens)
\layouts\labels_a4_3x7.php
\layouts\labels_a4l_13x5.php
\reports\defs\acquisitions.rpt
  Credit: as published on December 31, 2008 by hjtappe
  http://obiblio.sourceforge.net/index.php/Reports/Acquisitions
  Editorial change: .title acquisition => .title Acquisition
  lowercase sorts different in /reports/index.php
\reports\defs\authority.rpt
  Credit: OpenBiblio 1.0 Work in Progress / Micah Stetson
  Modified for 0.6.x database structure.
\reports\defs\authors.rpt
\reports\defs\biblioDuplicates.rpt
\reports\defs\bibliosByMARC.rpt
\reports\defs\bibliosBySubject.rpt
\reports\defs\checkoutStats.rpt
\reports\defs\copies.rpt
\reports\defs\popularAuthors.rpt
\reports\defs\popularBiblios.rpt
\reports\defs\popularSubjects.rpt
\reports\defs\subjects.rpt
  Credit: SQL based on patch 1118359 Add Browse by Subject / mtgstuber 
  (Michael Garrison Stuber)


Check the author's site for a feature list.


Q&A (Question and Answer)
-------------------------

Q Can I find someone who provides professional support for this package
  and / or OpenBiblio?

A Try any of the following:
  * Post your job description at the OpenBiblio Help Forum.
  * Follow the recommendations at:
  http://obiblio.sourceforge.net/index.php/Main/Customization

Q Can I translate the reports?

A Yes, you can modify the *.rpt files.
  Most reports in this package already have the double quotes needed if there is
  a space in the translation of a reports element.
  Suggestion: translate overdue letters first, if distributed to members.
