060rpt_nl_school3 - Customization package for OpenBiblio
Copyright � 2009 Hans van der Weij

Version
  Version 3 for OpenBiblio 0.6.x
  december 2009

License
  The license for this package is identical to the license for OpenBiblio,
  see COPYRIGHT.html - OpenBiblio release file
  (GNU GENERAL PUBLIC LICENSE Version 2, with minor exception)

  [citation of COPYRIGHT.html]

    OpenBiblio is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OpenBiblio; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  [end of citation]

Summary
  * Reports, report layouts for producing labels and letters.
  * Fields visible on New Bibliography and Edit Bibliography pages customized.
  Use with OpenBiblio 0.6.x integrated library software.
  Designed for secondary school libraries in the Netherlands ("mediatheken").
  Most reports are suitable for other libraries and countries, without any
  modification.

Language
  Dutch (.pdf overdue letter text)
  English (all reports)

Support
  OpenBiblio Help Forum (Community support)
  http://sourceforge.net/projects/obiblio/forums/forum/164978
  Hire someone for support? - see section Q&A

Contact author
  <jgvdweij at dds.nl>
    or
  http://sourceforge.net/users/infinite-mnkz/

OpenBiblio official Home Page and Project Page
  http://obiblio.sourceforge.net
  http://sourceforge.net/projects/obiblio


1. INSTALLATION
---------------


1.1 Quick install instructions 
------------------------------

* Copy supplied files to corresponding subdirectories in openbiblio directory.


1.2 Additional packages
-----------------------

Optional additional packages (add-ons and translations):
http://obiblio.sourceforge.net/index.php/Main/AddOns


2. DETAIL INFORMATION
---------------------


2.1 Customized biblio fields
-----------------
File /catalog/biblio_fields.php has a configuration area at the bottom that
determines which fields are used on pages New Bibliography and Edit Bibliography.
This package comes with a customized version, targeted at secondary school 
libraries in The Netherlands ("mediatheken").


2.2 Customized member fields
-----------------
Several reports and layouts are aware of custom member fields 'School Grade' and
'School Teacher'. These were standard in OpenBiblio version 0.5.1 and lower.


2.3 Customized definition files
-------------------------------

\catalog\biblio_fields.php
\layouts\cards_a4_2x4.php
\layouts\cards_a4_2x5.php
\layouts\labels.php
  Modified from original release: barcode dimensions are optimized for reliable 
  scanning results. Tested successfully with low-resolution inkjet printer.
  Credit for multifunctional label: OpenBiblio 0.4.0 / dstevens77 (Dave Stevens)
\layouts\labels_a4_3x7.php
\layouts\labels_a4l_13x5.php
\layouts\overdue.php
\reports\defs\acquisitions.rpt
  Credit: as published on December 31, 2008 by hjtappe
  http://obiblio.sourceforge.net/index.php/Reports/Acquisitions
  Editorial change: .title acquisition => .title Acquisition
  lowercase sorts different in /reports/index.php
\reports\defs\authority.rpt
  Credit: OpenBiblio 1.0 Work in Progress / Micah Stetson
  Modified for 0.6.x database structure.
\reports\defs\authors.rpt
\reports\defs\biblioDuplicates.rpt
\reports\defs\bibliosByMARC.rpt
\reports\defs\bibliosBySubject.rpt
\reports\defs\checkouts.rpt
\reports\defs\checkoutStats.rpt
\reports\defs\copies.rpt
\reports\defs\members.rpt
\reports\defs\popularAuthors.rpt
\reports\defs\popularBiblios.rpt
\reports\defs\popularSubjects.rpt
\reports\defs\subjects.rpt
  Credit: SQL based on patch 1118359 Add Browse by Subject / mtgstuber 
  (Michael Garrison Stuber)


Check the author's site for a feature list.


Q&A (Question and Answer)
-------------------------

Q Can I find someone who provides professional support for this package
  and / or OpenBiblio?

A Try any of the following:
  * Post your job description at the OpenBiblio Help Forum.
  * Follow the recommendations at:
  http://obiblio.sourceforge.net/index.php/Main/Customization

Q Why are only the .pdf overdue letters in the Dutch language?

A For the author this was a matter of priorities. Translating the overdue
  letters is essential because they will be read by library members.