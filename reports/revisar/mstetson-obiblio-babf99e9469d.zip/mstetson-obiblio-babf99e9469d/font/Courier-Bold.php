<?php
$PDF_font['type'] = 'Core';
$PDF_font['bbox'] = array(-113, -250, 749, 801);
for($i=0;$i<=255;$i++)
	$PDF_font['cw'][chr($i)]=600;
?>
