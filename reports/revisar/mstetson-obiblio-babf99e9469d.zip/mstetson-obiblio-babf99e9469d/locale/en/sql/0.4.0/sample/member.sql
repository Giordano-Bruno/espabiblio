insert into %prfx%member values (null,101,sysdate(),sysdate(),1,'Cat','Huckle','101 1st Street',null,'BusyTown','IA',12345,null,'111-222-3333',null,'me@mydomain.name','j',2,'Mrs. Applebee');
insert into %prfx%member values (null,102,sysdate(),sysdate(),1,'Baggins','Bilbo','Hole 1, 1st Street',null,'The Shire','IA',12345,null,'111-222-3333',null,'me@mydomain.name','a',null,null);
insert into %prfx%member values (null,103,sysdate(),sysdate(),1,'Baggins','Frodo','Hole 2, 1st Street',null,'The Shire','IA',12345,null,'111-222-3333',null,'me@mydomain.name','a',null,null);
