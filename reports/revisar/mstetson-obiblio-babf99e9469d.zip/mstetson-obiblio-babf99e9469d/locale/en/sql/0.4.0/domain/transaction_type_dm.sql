insert into %prfx%transaction_type_dm values ('-p','payment','Y');
insert into %prfx%transaction_type_dm values ('-r','credit','N');
insert into %prfx%transaction_type_dm values ('+c','charge','N');
