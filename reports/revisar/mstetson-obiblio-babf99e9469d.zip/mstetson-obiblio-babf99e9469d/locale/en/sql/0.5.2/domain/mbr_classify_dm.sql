insert into %prfx%mbr_classify_dm values (1,'adult','Y',0.00);
insert into %prfx%mbr_classify_dm values (2,'juvenile','N',0.00);
