insert into %prfx%member_fields values (1,'schoolGrade','2');
insert into %prfx%member_fields values (1,'schoolTeacher', 'Mrs. Applebee');
