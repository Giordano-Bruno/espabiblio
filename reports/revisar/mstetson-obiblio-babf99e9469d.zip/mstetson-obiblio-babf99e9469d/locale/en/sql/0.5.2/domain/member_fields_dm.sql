insert into %prfx%member_fields_dm values ('schoolGrade','School Grade','N');
insert into %prfx%member_fields_dm values ('schoolTeacher','School Teacher','N');
