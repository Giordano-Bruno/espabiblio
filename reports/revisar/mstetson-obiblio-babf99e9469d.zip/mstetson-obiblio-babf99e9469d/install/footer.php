<?php
/* This file is part of a copyrighted work; it is distributed with NO WARRANTY.
 * See the file COPYRIGHT.html for more details.
 */
 
?>
<!-- **************************************************************************************
     * Footer
     **************************************************************************************-->
<br><br><br>
</font>
<font face="Arial, Helvetica, sans-serif" size="1">
<center>
  Powered by OpenBiblio<br>
  Copyright &copy; 2002-2014 Dave Stevens, et al.<br>
  under the GNU General Public License
</center>
<br>
</font>
    </td>
  </tr>
</table>
</body>
</html>
